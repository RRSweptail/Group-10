class Doctor():
    def __init__(self,id,na,spe,tim,qua,roomno):
        self.id = id
        self.na = na   # doctor name
        self.spe = spe   # specialization
        self.tim = tim   # timing
        self.qua = qua   # qualification
        self.roomno = roomno   # room number
   
    def set_id(self,id):
        self.id=id    
    def set_na(self,na):
        self.na = na
    def set_spe(self,spe):
        self.spe = spe
    def set_tim(self,tim):
        self.tim = tim
    def set_qua(self,qua):
        self.qua = qua
    def set_roomno(self,roomno):
        self.roomno = roomno

    def getid(self):
        return (self.id)    
    def get_na(self):
        return (self.na)
    def get_spe(self):
        return (self.spe)
    def get_tim(self):
        return (self.tim)
    def get_qua(self):
        return (self.qua)
    def get_roomno(self):
        return (self.roomno)
    def __str__(self):
        return ({self.id}, {self.na}, {self.spe}, {self.tim}, {self.qua}, {self.roomno})
    
class do_ma():   # doctor manager
    def __init__(self):
        self.doc_li=[]
        self.rd_do_fi()

    def dr_info(self,do_in):   # doctor info
        return do_in.__str__()
    
    def enter_dr_info(self):   # enter doctor info
        id = input("Enter doctor's ID = ")
        na = input("Enter doctor's name = ")
        spe = input("Enter doctor's specialty = ")
        tim = input("Enter doctor's timing = ")
        qua = input("Enter the doctor's qualification = ")
        roomno = input("Enter doctor's room number = ")
        doc = Doctor(id,na,spe,tim,qua,roomno)
        return doc
    
    def rd_do_fi(self):   # read doctor file
        with open("doctors.txt", "r") as doctorfile:
            # del doctorfile[0]
            for do_li in doctorfile:
                data = do_li.strip().split('_')
                doctor = Doctor(data[0],data[1],data[2],data[3],data[4],data[5])
                self.doc_li.append(doctor)

    def se_do_by_id(self):   # search doctor by id
        id = str(input("Enter doctor's ID = "))
        t = 0
        for doctors in self.doc_li:
            if doctors.id == id:
                self.disp_doc_in(self.doc_li[0])
                self.disp_doc_in(doctors)
                return
        print("Cannot find the doctor with the ID on the system")

    def se_do_by_na(self):   # search doctor by name
        na = str(input("Enter doctor's name = "))
        for doctor in self.doc_li:
            if doctor.na == na:
                self.disp_doc_in(self.doc_li[0])
                self.disp_doc_in(doctor)
                return
        print("Cannot find the doctor with the name on the system")

    def disp_doc_in(self,doctors):   # display doctor information
            print(f" {doctors.id:<10}  {doctors.na:<20}  {doctors.spe:<14}  {doctors.tim:<20}  {doctors.qua:<15}  {doctors.roomno:<12} ")

    def disp_doc_li(self):   # display doctor list
        for doctors in self.doc_li:
            self.disp_doc_in(doctors)
    
    def edi_doc_in(self):   # edit doctor information
        id= int(input("Enter the id of doctor edit the information = "))
        for doctor in self.doc_li: 
             if str(doctor.get_id()) == str(id):
                Dr_na = input("Enter new name = ")
                Dr_spe = input("Enter new speciliality = ")
                Dr_tim = input("Enter new timing = ")
                Dr_qua = input("Enter new qualification = ") 
                Dr_roomno = input("Enter new room number = ")
                self.wr_li_of_doc_to_fi()
                print("Doctor whose id is", {doctor.getid()}, "is edited")
                return
             else:
                continue
        print("Cannot find the doctor") 

    def wr_li_of_doc_to_fi(self):   # write list of doctors to file
        with open("doctors.txt", "w") as list:
            for doctor in self.doc_li:
                list.write(self.dr_info(doctor)+"\n")

    def add_dr_info(self):   # add doctor information
        newDoctors = self.enter_dr_info()
        self.doc_li.append(newDoctors)
        with open("doctors.txt", "a") as list:
            list.write(self.dr_info(newDoctors))
        print("Doctor whose id is ",str(newDoctors.getid()),"is added.")

class Patient:
    def __init__(self,pid,na,dis,gender,age):
        self.pid=pid
        self.na=na
        self.dis=dis   # disease
        self.gender=gender
        self.age=age
        
    def set_pid(self,new_pid):
        self.pid=new_pid
    def set_na(self,new_na):
        self.na=new_na
    def set_dis(self,new_dis):
        self.dis=new_dis
    def set_gender(self,new_gender):
        self.gender=new_gender
    def set_age(self,new_age):
        self.age=new_age

    def get_pid(self):
        return self.pid
    def get_na(self):
        return self.na
    def get_dis(self):
        return self.dis
    def get_gender(self):
        return self.gender
    def get_age(self):
        return self.age
    def __str__(self):
        return f"{self.pid}_{self.na}_{self.dis}_{self.gender}_{self.age}"

class PatientManager:
    def __init__(self):
        self.pa_li = []   # patient list
        self.rd_pa_li()   # read patient file

    def for_pat_in(self, patient):   # format patient info
        return patient.__str__()
    
    def en_pat_in(self):   # enter patient info
        id = input("Enter patient's ID = ")
        na = input("Enter patient's name = ")
        dis = input("Enter patient's disease = ")
        gender = input("Enter patient's gender = ")
        age = input("Enter patient's age = ")
        ptn = Patient(id,na,dis,gender,age)
        return ptn
    
    def rd_pa_li(self):   # read patient list
        with open("patients.txt","r") as pa_fi:
            for pa_li in pa_fi :   # patient line, patient file 
              data = pa_li.strip().split("_")
              patient = Patient(data[0],data[1],data[2],data[3],data[4])
              self.pa_li.append(patient)

    def se_pa_by_id(self):   # search patient by id
        pa_id = str(input("Enter patient's ID = "))   # patient id
        for patient in self.pa_li:
            if str(patient.get_pid()) == str(pa_id):
                self.disp_pat_in(self.pa_li[0])   # display patient info
                self.disp_pat_in(patient)
                return
        print("Cannot find the Patient with the id on the system")

    def disp_pat_in(self, Patientinfo):   # display patient information
        print(f" {Patientinfo.pid:<10}  {Patientinfo.na:<10}  {Patientinfo.dis:<10}  {Patientinfo.gender:<10}  {Patientinfo.age:<10}")
    
    def ed_pat_in(self):   # edit patient info
        pa_id = int(input("Enter the id of the Patient to edit the information = "))
        for patient in self.pa_li:
            if str(patient.get_pid()) == str(pa_id):
                patient_na = input("Enter new name = ")
                patient_dis = input("Enter new disease = ")
                patient_gender = input("Enter new gender = ")
                patient_age = input("Enter new age = ")
                patient.set_na(patient_na)
                patient.set_dis(patient_dis)
                patient.set_gender(patient_gender)
                patient.set_age(patient_age)
                self.wr_li_of_pa()
                print("Patient whose id is", {patient.get_pid()}, "is added")
                return
            else:
                continue
        print("Cannot find the patient")
    
    def disp_pat_li(self):   # display patients list
        for patient in self.pa_li:
            self.disp_pat_in(patient)
    
    def wr_li_of_pa(self):   # write list of patients
        with open("patients.txt", "w") as list:
            for patient in self.pa_li:
                a=self.for_pat_in(patient)
                list.write(a+"\n")
    
    def add_pat_to_fi(self):   # add patient to file
        patient = self.en_pat_in()
        self.pa_li.append(patient)
        with open("patients.txt", "a") as list:
            list.write("\n")
            list.write(self.for_pat_in(patient))
        print("New patient whose id is", {patient.get_pid()}, "is  added.")

class Management:
    def init(self):
        self.do_ma = do_ma()
        self.patientmanager = PatientManager()
    
    def Menu(self):
        while True:
            print("Welcome to Calgary Hospital Managment System ")
            print("Select from the following options = ")
            print("1 - Doctors")
            print("2 - Patients")
            print("3 - Exit program")
            menu =input("Enter your choice (1-3) = ")
            print()
            if menu == "1":
                self.drsubmenu()
            elif menu == "2":
                self.patients_submenu()
            elif menu == "3":
                print("Thank you for coming.Bye!")
                break
    
    def drsubmenu(self):
        while True:
            print("Doctor Menu: ")
            print("1 -  Display doctors list")
            print("2 -  Search for doctor by ID")
            print("3 -  Search for doctor by na")
            print("4 -  Add Doctor")
            print("5 -  Edit Doctor info")
            print("6 -  Back to The  Main Menu")
            func=do_ma()
            menu = input("Enter your choice (1-6): ")
            if menu == "1":
                func.disp_doc_li()
            elif menu == "2":
                func.se_do_by_id()
            elif menu == "3":
                func.se_do_by_na()
            elif menu == "4":
                func.add_dr_info()
            elif menu == "5":
                func.edi_doc_in()
            elif menu == "6":
                break
    
    def patients_submenu(self):
        while True:
            print("Patient's Menu")
            print("1. Display patients list")
            print("2. Search for patient by ID")
            print("3. Add a new patient")
            print("4. Edit patient information")
            print("5. Return to Main Menu")
            func1=PatientManager()
            choice = input("Enter your choice (1-5): ")
            if choice == "1":
                func1.disp_pat_li()
            elif choice == "2":
                func1.se_pa_by_id()
            elif choice == "3":
                func1.add_pat_to_fi()
            elif choice == "4":
                func1.ed_pat_in()
            elif choice == "5":
                break  
s= Management()
s.Menu()